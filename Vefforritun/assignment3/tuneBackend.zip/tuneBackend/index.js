//Sample for Assignment 3
const express = require('express');

//Import a body parser module to be able to access the request body as json
const bodyParser = require('body-parser');

//Use cors to avoid issues with testing on localhost
const cors = require('cors');

const app = express();

//Port environment variable already set up to run on Heroku
let port = process.env.PORT || 3000;

const apiPath = '/api/';
const version = 'v1';

//Tell express to use the body parser module
app.use(bodyParser.json());

//Tell express to use cors -- enables CORS for this backend
app.use(cors());  

//Set Cors-related headers to prevent blocking of local requests
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

//The following is an example of an array of two tunes.  Compared to assignment 2, I have shortened the content to make it readable
let next_tune_id = 4;
var tunes = [
    { id: '0', name: "Für Elise", genreId: '1', content: [{note: "E5", duration: "8n", timing: 0},{ note: "D#5", duration: "8n", timing: 0.25},{ note: "E5", duration: "8n", timing: 0.5},{ note: "D#5", duration: "8n", timing: 0.75},
    { note: "E5", duration: "8n", timing: 1}, { note: "B4", duration: "8n", timing: 1.25}, { note: "D5", duration: "8n", timing: 1.5}, { note: "C5", duration: "8n", timing: 1.75},
    { note: "A4", duration: "4n", timing: 2}] },

    { id: '3', name: "Seven Nation Army", genreId: '0', 
    content: [{note: "E5", duration: "4n", timing: 0}, {note: "E5", duration: "8n", timing: 0.5}, {note: "G5", duration: "4n", timing: 0.75}, {note: "E5", duration: "8n", timing: 1.25}, {note: "E5", duration: "8n", timing: 1.75}, {note: "G5", duration: "4n", timing: 1.75}, {note: "F#5", duration: "4n", timing: 2.25}] }
];

let next_genre_id = 2;
let genres = [
    { id: '0', genreName: "Rock"},
    { id: '1', genreName: "Classic"}
];

//Your endpoints go here

app.get(apiPath + version + '/tunes', (req, res) => {
    let filter = req.query.filter
    let ret_tunes = [];
    for (let i = 0; i < tunes.length; i++) {
        if (filter) {
            if (filter != tunes[i].name) {
                continue;
            }
        }
        ret_tunes.push({id: tunes[i].id, name: tunes[i].name, genreId: tunes[i].genreId})
    }
    res.status(200).json(ret_tunes);
})

app.get(apiPath + version + '/tunes/:tunesId', (req, res) => {
    for (let i = 0; i < tunes.length; i++) {
        if (req.params.id == tunes[i].id) {
            return res.status(200).json(tunes[i]);
        }
    }
    res.status(404).json({message: "Tune with id " + req.params.id + " doesn't exists."});
})

app.post(apiPath + version + '/genres/:genreId/tunes', (req, res) => {
    let req_genreId = req.params.genreId;
    let req_content = req.body.content;
    let req_name = req.body.name;

    if (req_content != []) {
        for (let i = 0; i < genres.length; i++) {
            if (genres[i].id == req_genreId) {
                tune = {id: next_tune_id, name: req_name, genreId: req_genreId,content: req_content}
                next_tune_id++;
                tunes.push(tune)
                return res.status(201).json(tune);
            }
        }
    }
    res.status(400).json({message: "Genre with name: "  + " already exists."})

})

app.patch(apiPath + version + '/genres/:genreId/tunes/:tunesId', (req, res) => {

    for (let i = 0; i < tunes.length; i++){
        if (tunes[i].id == req.params.tunesId) {
            console.log(req.body)
            for (const [key, value] of Object.entries(req.body)) {
                console.log(key, value);
                tunes[i][key] = value
        }
        return res.status(200).json(tunes[i])
    }
}
    res.status(400).json('villa')
})




app.get(apiPath + version + '/genres', (req, res) => {
    res.status(200).json(genres);
})

app.post(apiPath + version + '/genres', (req, res) => {
    let body = req.body;
    let name = body.genreName;

    if (!genres.some(item => item.genreName === name)) {
        let new_genre = {id: next_genre_id.toString(), genreName: name}
        next_genre_id++;
        genres.push(new_genre);
        return res.status(201).json(new_genre);
    }
    res.status(400).json({message: "Genre with name: " + name + " already exists."});    
})

app.delete(apiPath + version + '/genres/:genresId', (req, res) => {
    let id = req.params.genresid;
    if (!tunes.some(item => item.genreId === id)) {
        if (genres.some(item => item.id === id)) {
            let del_genre = {};
            for (let i = 0; i < genres.length; i++) {
                if (genres[i].id == id) {
                    del_genre = genres[i];
                    break;
                }
            }
            genres = genres.filter(item => item.id != id)
            return res.status(200).json(del_genre);
        }
        res.status(400).json({message: "Genre can't be found."});    
    }
    res.status(400).json({message: "Genre can't be used in tunes."});    
})
/*app.use('*', function(req, res){
    res.status(405).send('Unsupported operation.');
  });
*/
//Start the server
app.listen(port, () => {
    console.log('Tune app listening on port + ' + port);
});